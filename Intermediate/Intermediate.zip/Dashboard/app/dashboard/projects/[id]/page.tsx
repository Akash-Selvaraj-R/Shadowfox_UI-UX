import { ProjectDetails } from "@/components/dashboard/projects/project-details"

export default function ProjectPage({ params }: { params: { id: string } }) {
  return <ProjectDetails id={params.id} />
}

import { ClientDetails } from "@/components/dashboard/clients/client-details"

export default function ClientPage({ params }: { params: { id: string } }) {
  return <ClientDetails id={params.id} />
}

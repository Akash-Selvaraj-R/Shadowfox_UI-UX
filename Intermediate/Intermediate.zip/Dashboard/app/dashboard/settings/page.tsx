import { SettingsForm } from "@/components/dashboard/settings/settings-form"

export default function SettingsPage() {
  return <SettingsForm />
}

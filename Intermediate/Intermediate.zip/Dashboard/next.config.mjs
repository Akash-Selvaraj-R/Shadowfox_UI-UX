/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['assets.example.com'],
    unoptimized: true,
  },
  // For Framer Motion and other animation libraries
  compiler: {
    styledComponents: true,
  },
  // Prevent document is not defined errors
  experimental: {
    // This will allow Next.js to detect the root directory of the project
    // and enable the appropriate rendering mode
    appDir: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
}

export default nextConfig

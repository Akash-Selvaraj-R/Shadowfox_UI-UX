"use client"

import { useEffect, useState, useCallback } from "react"

export function useMobile() {
  const [isMobile, setIsMobile] = useState(false)

  // Use useCallback to prevent recreating this function on every render
  const checkIfMobile = useCallback(() => {
    if (typeof window !== "undefined") {
      setIsMobile(window.innerWidth < 768)
    }
  }, [])

  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    // Initial check
    checkIfMobile()

    // Add event listener
    window.addEventListener("resize", checkIfMobile)

    // Clean up
    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [checkIfMobile]) // Only re-run if checkIfMobile changes

  return isMobile
}

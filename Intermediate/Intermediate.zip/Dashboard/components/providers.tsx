"use client"

import type { ReactNode } from "react"
import { AnimatePresence } from "framer-motion"
import { memo } from "react"

interface ProvidersProps {
  children: ReactNode
}

export const Providers = memo(function Providers({ children }: ProvidersProps) {
  return <AnimatePresence mode="wait">{children}</AnimatePresence>
})

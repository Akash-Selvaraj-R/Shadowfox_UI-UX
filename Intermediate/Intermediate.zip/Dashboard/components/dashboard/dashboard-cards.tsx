"use client"

import { motion } from "framer-motion"
import { ArrowDownIcon, ArrowUpIcon, BarChart3, DollarSign, Users, Clock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function DashboardCards() {
  const cards = [
    {
      title: "Total Revenue",
      value: "$45,231.89",
      change: "+20.1%",
      isPositive: true,
      icon: DollarSign,
    },
    {
      title: "Active Users",
      value: "2,350",
      change: "+12.5%",
      isPositive: true,
      icon: Users,
    },
    {
      title: "Conversion Rate",
      value: "3.2%",
      change: "-4.1%",
      isPositive: false,
      icon: BarChart3,
    },
    {
      title: "Avg. Session",
      value: "2m 56s",
      change: "+10.3%",
      isPositive: true,
      icon: Clock,
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {cards.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
              <card.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{card.value}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                {card.isPositive ? (
                  <ArrowUpIcon className="mr-1 h-4 w-4 text-green-500" />
                ) : (
                  <ArrowDownIcon className="mr-1 h-4 w-4 text-red-500" />
                )}
                <span className={card.isPositive ? "text-green-500" : "text-red-500"}>{card.change}</span>
                <span className="ml-1">from last month</span>
              </p>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}

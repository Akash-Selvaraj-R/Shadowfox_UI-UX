"use client"

import { X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

interface NotificationModalProps {
  open: boolean
  onClose: () => void
}

export function NotificationModal({ open, onClose }: NotificationModalProps) {
  const notifications = [
    {
      id: 1,
      title: "New comment on your post",
      description: "John Doe commented on your latest post",
      time: "2 minutes ago",
      read: false,
    },
    {
      id: 2,
      title: "Your subscription is expiring",
      description: "Your premium subscription will expire in 3 days",
      time: "1 hour ago",
      read: false,
    },
    {
      id: 3,
      title: "New feature available",
      description: "Check out the new analytics dashboard features",
      time: "3 hours ago",
      read: true,
    },
    {
      id: 4,
      title: "System maintenance",
      description: "Scheduled maintenance on July 15th at 2:00 AM UTC",
      time: "Yesterday",
      read: true,
    },
    {
      id: 5,
      title: "Your report is ready",
      description: "The monthly analytics report is now available",
      time: "2 days ago",
      read: true,
    },
  ]

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
            transition={{ type: "spring", damping: 25 }}
            className="fixed right-0 top-0 z-50 h-full w-full max-w-sm border-l bg-background p-6 shadow-lg"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Notifications</h2>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-5 w-5" />
                <span className="sr-only">Close</span>
              </Button>
            </div>

            <ScrollArea className="h-[calc(100vh-8rem)] py-4">
              <div className="space-y-4">
                {notifications.map((notification, index) => (
                  <motion.div
                    key={notification.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`rounded-lg border p-4 ${notification.read ? "bg-background" : "bg-muted"}`}
                  >
                    <div className="mb-1 font-medium">{notification.title}</div>
                    <p className="text-sm text-muted-foreground">{notification.description}</p>
                    <div className="mt-2 text-xs text-muted-foreground">{notification.time}</div>
                  </motion.div>
                ))}
              </div>
            </ScrollArea>

            <div className="mt-4 flex justify-center">
              <Button variant="outline" className="w-full">
                Mark all as read
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

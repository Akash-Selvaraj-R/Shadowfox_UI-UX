"use client"

import { useState, useEffect, useCallback } from "react"
import { DashboardSidebar } from "./sidebar"
import { DashboardHeader } from "./header"
import { DashboardOverview } from "./overview"
import { useToast } from "@/components/ui/use-toast"
import { AnimatePresence, motion } from "framer-motion"
import { useMobile } from "@/hooks/use-mobile"

export function DashboardShell() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [mounted, setMounted] = useState(false)
  const isMobile = useMobile()
  const { toast } = useToast()

  // Handle mounting state to avoid hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  // Auto-close sidebar on mobile - only run once when isMobile changes
  useEffect(() => {
    if (isMobile && mounted) {
      setSidebarOpen(false)
    }
  }, [isMobile, mounted])

  const toggleSidebar = useCallback(() => {
    setSidebarOpen((prev) => !prev)
    toast({
      title: sidebarOpen ? "Sidebar collapsed" : "Sidebar expanded",
      duration: 1500,
    })
  }, [sidebarOpen, toast])

  // Don't render UI until client-side
  if (!mounted) {
    return <div className="h-screen bg-background"></div>
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <AnimatePresence initial={false}>
        {(sidebarOpen || !isMobile) && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: isMobile ? "100%" : "280px", opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className={`${isMobile ? "fixed inset-0 z-50" : "relative"}`}
          >
            <DashboardSidebar />
          </motion.div>
        )}
      </AnimatePresence>
      <div className="flex flex-col flex-1 overflow-hidden">
        <DashboardHeader />
        <DashboardOverview />
      </div>
    </div>
  )
}

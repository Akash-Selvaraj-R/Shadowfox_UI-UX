"use client"

import { useEffect, useRef } from "react"
import dynamic from "next/dynamic"
import { Card } from "@/components/ui/card"

// Dynamically import lottie with no SSR
const Lottie = dynamic(() => import("lottie-web"), { ssr: false })

export function LoadingAnimation() {
  const animationContainer = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (animationContainer.current) {
      const anim = Lottie.loadAnimation({
        container: animationContainer.current,
        renderer: "svg",
        loop: true,
        autoplay: true,
        path: "https://assets5.lottiefiles.com/packages/lf20_usmfx6bp.json",
      })

      return () => {
        anim.destroy()
      }
    }
  }, [])

  return (
    <Card className="flex items-center justify-center p-8">
      <div ref={animationContainer} className="h-40 w-40" />
    </Card>
  )
}

"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { PageTransition } from "@/components/page-transition"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Edit, Trash, Calendar, DollarSign, Users } from "lucide-react"

// Sample project data
const projectsData = {
  "1": {
    id: "1",
    name: "Website Redesign",
    client: "Acme Inc",
    clientId: "1",
    startDate: "2023-01-15",
    deadline: "2023-04-30",
    status: "In Progress",
    budget: "$15,000",
    progress: 65,
    description: "Complete redesign of the company website with modern UI/UX principles.",
    team: [
      { id: "1", name: "Alice Johnson", role: "Project Manager" },
      { id: "2", name: "Bob Smith", role: "UI/UX Designer" },
      { id: "3", name: "Charlie Brown", role: "Frontend Developer" },
    ],
    tasks: [
      { id: "1", name: "Requirements Gathering", status: "Completed", assignee: "Alice Johnson" },
      { id: "2", name: "Wireframing", status: "Completed", assignee: "Bob Smith" },
      { id: "3", name: "UI Design", status: "Completed", assignee: "Bob Smith" },
      { id: "4", name: "Frontend Development", status: "In Progress", assignee: "Charlie Brown" },
      { id: "5", name: "Backend Integration", status: "Pending", assignee: "Charlie Brown" },
      { id: "6", name: "Testing", status: "Pending", assignee: "Alice Johnson" },
    ],
  },
  "2": {
    id: "2",
    name: "Mobile App",
    client: "Acme Inc",
    clientId: "1",
    startDate: "2022-10-01",
    deadline: "2023-02-28",
    status: "Completed",
    budget: "$25,000",
    progress: 100,
    description: "Development of a mobile application for iOS and Android platforms.",
    team: [
      { id: "1", name: "Alice Johnson", role: "Project Manager" },
      { id: "4", name: "David Wilson", role: "Mobile Developer" },
      { id: "5", name: "Eve Davis", role: "QA Engineer" },
    ],
    tasks: [
      { id: "7", name: "Requirements Gathering", status: "Completed", assignee: "Alice Johnson" },
      { id: "8", name: "UI/UX Design", status: "Completed", assignee: "Bob Smith" },
      { id: "9", name: "iOS Development", status: "Completed", assignee: "David Wilson" },
      { id: "10", name: "Android Development", status: "Completed", assignee: "David Wilson" },
      { id: "11", name: "Testing", status: "Completed", assignee: "Eve Davis" },
      { id: "12", name: "Deployment", status: "Completed", assignee: "Alice Johnson" },
    ],
  },
}

interface ProjectDetailsProps {
  id: string
}

export function ProjectDetails({ id }: ProjectDetailsProps) {
  const [activeTab, setActiveTab] = useState("overview")
  const router = useRouter()

  // Get project data based on ID
  const project = projectsData[id as keyof typeof projectsData]

  // Handle if project not found
  if (!project) {
    return (
      <div className="container p-6 flex flex-col items-center justify-center h-full">
        <h1 className="text-2xl font-bold mb-4">Project not found</h1>
        <Button onClick={() => router.push("/dashboard/projects")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Projects
        </Button>
      </div>
    )
  }

  return (
    <PageTransition>
      <div className="container p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard/projects")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-bold tracking-tight">{project.name}</h1>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </Button>
            <Button variant="destructive">
              <Trash className="mr-2 h-4 w-4" />
              Delete
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Status</CardTitle>
              <div
                className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${
                  project.status === "Completed"
                    ? "bg-green-100 text-green-800"
                    : project.status === "In Progress"
                      ? "bg-blue-100 text-blue-800"
                      : "bg-yellow-100 text-yellow-800"
                }`}
              >
                {project.status}
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground">Progress</div>
              <div className="mt-2 space-y-2">
                <Progress value={project.progress} className="h-2" />
                <div className="text-xs text-right text-muted-foreground">{project.progress}%</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Timeline</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground">Start Date</div>
                  <div className="font-medium">{project.startDate}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Deadline</div>
                  <div className="font-medium">{project.deadline}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Budget</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{project.budget}</div>
              <div className="text-xs text-muted-foreground">Client: {project.client}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
            <TabsTrigger value="team">Team</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Project Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{project.description}</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tasks" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Tasks</CardTitle>
                <CardDescription>Project tasks and their current status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {project.tasks.map((task) => (
                    <div
                      key={task.id}
                      className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                    >
                      <div>
                        <h3 className="font-medium">{task.name}</h3>
                        <p className="text-sm text-muted-foreground">Assigned to: {task.assignee}</p>
                      </div>
                      <span
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                          task.status === "Completed"
                            ? "bg-green-100 text-green-800"
                            : task.status === "In Progress"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {task.status}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="team" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Team Members</CardTitle>
                <CardDescription>People working on this project</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {project.team.map((member) => (
                    <div key={member.id} className="flex items-center gap-4 border-b pb-4 last:border-0 last:pb-0">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <Users className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">{member.name}</h3>
                        <p className="text-sm text-muted-foreground">{member.role}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageTransition>
  )
}

"use client"

import { memo } from "react"
import { ArrowDownIcon, ArrowUpIcon, Users, FolderKanban, Clock, DollarSign } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const cards = [
  {
    title: "Total Clients",
    value: "24",
    change: "+2",
    changeText: "from last month",
    isPositive: true,
    icon: Users,
  },
  {
    title: "Active Projects",
    value: "12",
    change: "-1",
    changeText: "from last month",
    isPositive: false,
    icon: FolderKanban,
  },
  {
    title: "Average Completion",
    value: "18 days",
    change: "-2 days",
    changeText: "from last month",
    isPositive: true,
    icon: Clock,
  },
  {
    title: "Total Revenue",
    value: "$48,500",
    change: "+12%",
    changeText: "from last month",
    isPositive: true,
    icon: DollarSign,
  },
]

export const DashboardCards = memo(function DashboardCards() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => (
        <Card key={card.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
            <card.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{card.value}</div>
            <p className="text-xs text-muted-foreground flex items-center mt-1">
              {card.isPositive ? (
                <ArrowUpIcon className="mr-1 h-4 w-4 text-green-500" />
              ) : (
                <ArrowDownIcon className="mr-1 h-4 w-4 text-red-500" />
              )}
              <span className={card.isPositive ? "text-green-500" : "text-red-500"}>{card.change}</span>
              <span className="ml-1">{card.changeText}</span>
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
})

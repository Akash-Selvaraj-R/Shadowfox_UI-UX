"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { BarChart3, Calendar, CreditCard, Home, Settings, Users, X, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useToast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"

interface DashboardSidebarProps {
  onClose: () => void
  isMobile: boolean
}

interface SidebarItem {
  title: string
  icon: React.ElementType
  href: string
  isActive?: boolean
}

export function DashboardSidebar({ onClose, isMobile }: DashboardSidebarProps) {
  const { toast } = useToast()
  const [activeItem, setActiveItem] = useState("Dashboard")

  const sidebarItems: SidebarItem[] = [
    { title: "Dashboard", icon: Home, href: "#", isActive: true },
    { title: "Analytics", icon: BarChart3, href: "#" },
    { title: "Team", icon: Users, href: "#" },
    { title: "Calendar", icon: Calendar, href: "#" },
    { title: "Billing", icon: CreditCard, href: "#" },
    { title: "Settings", icon: Settings, href: "#" },
  ]

  const handleItemClick = (title: string) => {
    setActiveItem(title)
    toast({
      title: `Navigated to ${title}`,
      duration: 1500,
    })

    if (isMobile) {
      onClose()
    }
  }

  return (
    <div className="flex h-full flex-col border-r bg-background">
      <div className="flex h-16 items-center border-b px-6">
        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="flex items-center gap-2 font-semibold"
        >
          <BarChart3 className="h-6 w-6 text-primary" />
          <span>Client Dashboard</span>
        </motion.div>
        {isMobile && (
          <Button variant="ghost" size="icon" onClick={onClose} className="ml-auto">
            <X className="h-5 w-5" />
            <span className="sr-only">Close sidebar</span>
          </Button>
        )}
      </div>
      <ScrollArea className="flex-1 px-4 py-6">
        <nav className="flex flex-col gap-2">
          {sidebarItems.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <Button
                variant={activeItem === item.title ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start gap-2",
                  activeItem === item.title && "bg-primary text-primary-foreground",
                )}
                onClick={() => handleItemClick(item.title)}
              >
                <item.icon className="h-5 w-5" />
                {item.title}
              </Button>
            </motion.div>
          ))}
        </nav>
      </ScrollArea>
      <div className="border-t p-4">
        <Button variant="outline" className="w-full justify-start gap-2">
          <LogOut className="h-5 w-5" />
          Log out
        </Button>
      </div>
    </div>
  )
}

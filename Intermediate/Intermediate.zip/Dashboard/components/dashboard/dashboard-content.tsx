"use client"

import { Suspense, useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ScrollArea } from "@/components/ui/scroll-area"
import { DashboardCards } from "./dashboard-cards"
import { DashboardCharts } from "./dashboard-charts"

export function DashboardContent() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="flex-1 bg-background"></div>
  }

  return (
    <ScrollArea className="flex-1">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="container mx-auto p-4 md:p-6 space-y-8"
      >
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here's an overview of your project metrics.</p>
        </div>

        <Suspense fallback={<div className="h-40 w-full bg-muted/20 animate-pulse rounded-lg"></div>}>
          <DashboardCards />
        </Suspense>

        <Suspense fallback={<div className="h-80 w-full bg-muted/20 animate-pulse rounded-lg"></div>}>
          <DashboardCharts />
        </Suspense>
      </motion.div>
    </ScrollArea>
  )
}

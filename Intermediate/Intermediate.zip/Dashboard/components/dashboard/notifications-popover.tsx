"use client"

import { X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { memo } from "react"

interface NotificationsPopoverProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export const NotificationsPopover = memo(function NotificationsPopover({
  open,
  onOpenChange,
}: NotificationsPopoverProps) {
  const notifications = [
    {
      id: 1,
      title: "New client request",
      description: "John Doe has requested access to the project",
      time: "2 minutes ago",
      read: false,
    },
    {
      id: 2,
      title: "Project deadline approaching",
      description: "The Marketing Campaign project is due in 2 days",
      time: "1 hour ago",
      read: false,
    },
    {
      id: 3,
      title: "New comment on project",
      description: "Sarah left a comment on Website Redesign",
      time: "3 hours ago",
      read: true,
    },
    {
      id: 4,
      title: "Invoice paid",
      description: "Invoice #1234 has been paid",
      time: "Yesterday",
      read: true,
    },
  ]

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black"
            onClick={() => onOpenChange(false)}
          />
          <motion.div
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
            transition={{ type: "spring", damping: 25 }}
            className="fixed right-0 top-0 z-50 h-full w-full max-w-sm border-l bg-background p-6 shadow-lg"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Notifications</h2>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}>
                <X className="h-5 w-5" />
                <span className="sr-only">Close</span>
              </Button>
            </div>

            <ScrollArea className="h-[calc(100vh-8rem)] py-4">
              <div className="space-y-4">
                {notifications.map((notification, index) => (
                  <motion.div
                    key={notification.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`rounded-lg border p-4 ${notification.read ? "bg-background" : "bg-muted"}`}
                  >
                    <div className="mb-1 font-medium">{notification.title}</div>
                    <p className="text-sm text-muted-foreground">{notification.description}</p>
                    <div className="mt-2 text-xs text-muted-foreground">{notification.time}</div>
                  </motion.div>
                ))}
              </div>
            </ScrollArea>

            <div className="mt-4 flex justify-center">
              <Button variant="outline" className="w-full">
                Mark all as read
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
})

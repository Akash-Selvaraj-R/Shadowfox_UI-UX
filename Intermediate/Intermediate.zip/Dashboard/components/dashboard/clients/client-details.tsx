"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { PageTransition } from "@/components/page-transition"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Edit, Trash } from "lucide-react"

// Sample client data
const clientsData = {
  "1": {
    id: "1",
    name: "Acme Inc",
    contact: "John Doe",
    email: "john@acme.com",
    phone: "(555) 123-4567",
    address: "123 Main St, Anytown, USA",
    website: "https://acme.example.com",
    projects: [
      { id: "1", name: "Website Redesign", status: "In Progress" },
      { id: "2", name: "Mobile App", status: "Completed" },
      { id: "3", name: "Marketing Campaign", status: "Planning" },
    ],
    notes: "Acme Inc. is a long-term client with multiple ongoing projects.",
    joinedDate: "January 15, 2022",
  },
  "2": {
    id: "2",
    name: "Globex Corporation",
    contact: "Jane Smith",
    email: "jane@globex.com",
    phone: "(555) 987-6543",
    address: "456 Business Ave, Commerce City, USA",
    website: "https://globex.example.com",
    projects: [
      { id: "4", name: "E-commerce Platform", status: "In Progress" },
      { id: "5", name: "CRM Integration", status: "Planning" },
    ],
    notes: "Globex Corporation is expanding their digital presence.",
    joinedDate: "March 22, 2022",
  },
}

interface ClientDetailsProps {
  id: string
}

export function ClientDetails({ id }: ClientDetailsProps) {
  const [activeTab, setActiveTab] = useState("overview")
  const router = useRouter()

  // Get client data based on ID
  const client = clientsData[id as keyof typeof clientsData]

  // Handle if client not found
  if (!client) {
    return (
      <div className="container p-6 flex flex-col items-center justify-center h-full">
        <h1 className="text-2xl font-bold mb-4">Client not found</h1>
        <Button onClick={() => router.push("/dashboard/clients")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Clients
        </Button>
      </div>
    )
  }

  return (
    <PageTransition>
      <div className="container p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard/clients")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-bold tracking-tight">{client.name}</h1>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </Button>
            <Button variant="destructive">
              <Trash className="mr-2 h-4 w-4" />
              Delete
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="notes">Notes</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-6">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="grid grid-cols-3 gap-1">
                    <div className="font-medium">Contact Person</div>
                    <div className="col-span-2">{client.contact}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    <div className="font-medium">Email</div>
                    <div className="col-span-2">{client.email}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    <div className="font-medium">Phone</div>
                    <div className="col-span-2">{client.phone}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    <div className="font-medium">Address</div>
                    <div className="col-span-2">{client.address}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    <div className="font-medium">Website</div>
                    <div className="col-span-2">
                      <a
                        href={client.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                      >
                        {client.website}
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Client Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="grid grid-cols-3 gap-1">
                    <div className="font-medium">Client ID</div>
                    <div className="col-span-2">{client.id}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    <div className="font-medium">Joined Date</div>
                    <div className="col-span-2">{client.joinedDate}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    <div className="font-medium">Projects</div>
                    <div className="col-span-2">{client.projects.length}</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="projects" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Projects</CardTitle>
                <CardDescription>Projects associated with {client.name}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {client.projects.map((project) => (
                    <div
                      key={project.id}
                      className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                    >
                      <div>
                        <h3 className="font-medium">{project.name}</h3>
                        <p className="text-sm text-muted-foreground">ID: {project.id}</p>
                      </div>
                      <span
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                          project.status === "Completed"
                            ? "bg-green-100 text-green-800"
                            : project.status === "In Progress"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {project.status}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notes" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Notes</CardTitle>
                <CardDescription>Additional information about {client.name}</CardDescription>
              </CardHeader>
              <CardContent>
                <p>{client.notes}</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageTransition>
  )
}

"use client"

import { useState, useCallback, memo } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { BarChart3, Users, FolderKanban, Settings, ChevronLeft, ChevronRight, Home } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

const navItems = [
  {
    title: "Overview",
    href: "/dashboard",
    icon: Home,
  },
  {
    title: "Clients",
    href: "/dashboard/clients",
    icon: Users,
    submenu: [
      { title: "All Clients", href: "/dashboard/clients" },
      { title: "Add New Client", href: "/dashboard/clients/new" },
    ],
  },
  {
    title: "Projects",
    href: "/dashboard/projects",
    icon: FolderKanban,
    submenu: [
      { title: "All Projects", href: "/dashboard/projects" },
      { title: "Add New Project", href: "/dashboard/projects/new" },
    ],
  },
  {
    title: "Analytics",
    href: "/dashboard/analytics",
    icon: BarChart3,
  },
  {
    title: "Settings",
    href: "/dashboard/settings",
    icon: Settings,
  },
]

export const DashboardSidebar = memo(function DashboardSidebar() {
  const [collapsed, setCollapsed] = useState(false)
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null)
  const pathname = usePathname()

  const toggleCollapsed = useCallback(() => {
    setCollapsed((prev) => !prev)
  }, [])

  const toggleSubmenu = useCallback((title: string) => {
    setOpenSubmenu((prev) => (prev === title ? null : title))
  }, [])

  const isActive = useCallback(
    (href: string) => {
      if (href === "/dashboard") {
        return pathname === "/dashboard"
      }
      return pathname.startsWith(href)
    },
    [pathname],
  )

  return (
    <motion.div
      initial={false}
      animate={{ width: collapsed ? 80 : 280 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className="relative h-screen border-r bg-background"
    >
      <div className="flex h-16 items-center justify-between px-4 border-b">
        <AnimatePresence initial={false} mode="wait">
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="font-semibold text-xl flex items-center gap-2"
            >
              <BarChart3 className="h-6 w-6" />
              <span>Dashboard</span>
            </motion.div>
          )}
        </AnimatePresence>
        <Button variant="ghost" size="icon" onClick={toggleCollapsed} className="ml-auto">
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>
      <ScrollArea className="h-[calc(100vh-4rem)]">
        <nav className="p-2">
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.title}>
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    isActive(item.href) ? "bg-primary text-primary-foreground" : "hover:bg-muted",
                  )}
                  onClick={(e) => {
                    if (item.submenu) {
                      e.preventDefault()
                      toggleSubmenu(item.title)
                    }
                  }}
                >
                  <item.icon className="h-5 w-5" />
                  <AnimatePresence initial={false} mode="wait">
                    {!collapsed && (
                      <motion.span
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="flex-1"
                      >
                        {item.title}
                      </motion.span>
                    )}
                  </AnimatePresence>
                  {!collapsed && item.submenu && (
                    <ChevronRight
                      className={cn("h-4 w-4 transition-transform", openSubmenu === item.title && "rotate-90")}
                    />
                  )}
                </Link>
                {!collapsed && item.submenu && openSubmenu === item.title && (
                  <motion.ul
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="mt-1 space-y-1 pl-10"
                  >
                    {item.submenu.map((subitem) => (
                      <li key={subitem.title}>
                        <Link
                          href={subitem.href}
                          className={cn(
                            "block rounded-md px-3 py-2 text-sm font-medium transition-colors",
                            pathname === subitem.href ? "bg-primary text-primary-foreground" : "hover:bg-muted",
                          )}
                        >
                          {subitem.title}
                        </Link>
                      </li>
                    ))}
                  </motion.ul>
                )}
              </li>
            ))}
          </ul>
        </nav>
      </ScrollArea>
    </motion.div>
  )
})

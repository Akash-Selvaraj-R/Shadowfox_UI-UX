"use client"

import { motion } from "framer-motion"
import Image from "next/image"

export default function About() {
  const stats = [
    { value: "10+", label: "Years Experience" },
    { value: "200+", label: "Projects Completed" },
    { value: "50+", label: "Team Members" },
    { value: "99%", label: "Client Satisfaction" },
  ]

  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-primary/20 rounded-lg -z-10" />
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-primary/20 rounded-lg -z-10" />
              <div className="relative overflow-hidden rounded-lg shadow-xl">
                <Image
                  src="https://shadowfox.in/images/org-logo.png"
                  alt="About ShadowFox"
                  width={600}
                  height={600}
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">About ShadowFox</h2>
            <div className="w-20 h-1 bg-primary mb-6" />

            <p className="text-muted-foreground mb-6">
              ShadowFox is a leading digital solutions provider founded in 2013. We specialize in creating innovative
              digital products that help businesses transform their operations and reach their full potential.
            </p>

            <p className="text-muted-foreground mb-8">
              Our team of experts combines technical expertise with creative thinking to deliver solutions that not only
              meet but exceed our clients' expectations. We believe in building long-term relationships with our clients
              and becoming their trusted technology partner.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-3xl font-bold text-primary mb-2">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </div>

            <div className="flex flex-wrap gap-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.6 }}
                className="flex items-center gap-2"
              >
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span>Innovative Solutions</span>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.7 }}
                className="flex items-center gap-2"
              >
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span>Customer-Centric Approach</span>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.8 }}
                className="flex items-center gap-2"
              >
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span>Quality Assurance</span>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.9 }}
                className="flex items-center gap-2"
              >
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span>Continuous Support</span>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

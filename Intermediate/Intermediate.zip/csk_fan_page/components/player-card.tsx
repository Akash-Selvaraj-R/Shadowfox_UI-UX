"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"

interface PlayerStats {
  matches?: number
  runs?: number
  wickets?: number
  average?: number
  economy?: number
}

interface PlayerProps {
  id: number
  name: string
  role: string
  image: string
  stats: PlayerStats
}

export default function PlayerCard({ player }: { player: PlayerProps }) {
  const [isFlipped, setIsFlipped] = useState(false)

  return (
    <div
      className="h-[400px] w-full perspective"
      onMouseEnter={() => setIsFlipped(true)}
      onMouseLeave={() => setIsFlipped(false)}
    >
      <motion.div
        className="relative w-full h-full preserve-3d cursor-pointer"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Front of card */}
        <div className="absolute w-full h-full backface-hidden">
          <Card className="w-full h-full overflow-hidden border-2 border-yellow-500">
            <div className="relative h-[280px] bg-gradient-to-b from-yellow-500 to-blue-900">
              <Image
                src={player.image || "/placeholder.svg"}
                alt={player.name}
                fill
                className="object-cover object-top"
              />
            </div>
            <CardContent className="p-4 text-center">
              <Badge className="mb-2 bg-yellow-500 text-blue-900">{player.role}</Badge>
              <h3 className="text-xl font-bold text-blue-900">{player.name}</h3>
            </CardContent>
          </Card>
        </div>

        {/* Back of card */}
        <div className="absolute w-full h-full backface-hidden rotateY-180">
          <Card className="w-full h-full border-2 border-yellow-500 flex flex-col">
            <CardContent className="p-6 flex-1 flex flex-col justify-center">
              <h3 className="text-xl font-bold text-blue-900 mb-4 text-center">{player.name}</h3>
              <div className="space-y-4">
                {player.stats.matches && (
                  <div>
                    <p className="text-sm text-gray-500">Matches</p>
                    <p className="text-lg font-bold text-blue-900">{player.stats.matches}</p>
                  </div>
                )}

                {player.stats.runs && (
                  <div>
                    <p className="text-sm text-gray-500">Runs</p>
                    <p className="text-lg font-bold text-blue-900">{player.stats.runs}</p>
                  </div>
                )}

                {player.stats.wickets && (
                  <div>
                    <p className="text-sm text-gray-500">Wickets</p>
                    <p className="text-lg font-bold text-blue-900">{player.stats.wickets}</p>
                  </div>
                )}

                {player.stats.average && (
                  <div>
                    <p className="text-sm text-gray-500">Average</p>
                    <p className="text-lg font-bold text-blue-900">{player.stats.average}</p>
                  </div>
                )}

                {player.stats.economy && (
                  <div>
                    <p className="text-sm text-gray-500">Economy</p>
                    <p className="text-lg font-bold text-blue-900">{player.stats.economy}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </div>
  )
}

"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Trophy } from "lucide-react"

export default function FanPoll() {
  const [polls, setPolls] = useState([
    {
      id: 1,
      question: "Who will be the top scorer for CSK this season?",
      options: [
        { id: 1, text: "MS Dhoni", votes: 450 },
        { id: 2, text: "Ruturaj Gaikwad", votes: 320 },
        { id: 3, text: "Ravindra Jadeja", votes: 180 },
        { id: 4, text: "Devon Conway", votes: 150 },
      ],
      totalVotes: 1100,
      userVoted: null,
      isActive: true,
    },
    {
      id: 2,
      question: "Will CSK qualify for the playoffs this season?",
      options: [
        { id: 1, text: "Yes, definitely", votes: 780 },
        { id: 2, text: "No", votes: 120 },
        { id: 3, text: "Too early to say", votes: 250 },
      ],
      totalVotes: 1150,
      userVoted: null,
      isActive: true,
    },
  ])

  const [userPoints, setUserPoints] = useState(120)
  const [activePollIndex, setActivePollIndex] = useState(0)

  const handleVote = (pollId: number, optionId: number) => {
    setPolls(
      polls.map((poll) => {
        if (poll.id === pollId) {
          const updatedOptions = poll.options.map((option) => {
            if (option.id === optionId) {
              return { ...option, votes: option.votes + 1 }
            }
            return option
          })

          return {
            ...poll,
            options: updatedOptions,
            totalVotes: poll.totalVotes + 1,
            userVoted: optionId,
          }
        }
        return poll
      }),
    )

    // Award points for voting
    setUserPoints(userPoints + 10)
  }

  const calculatePercentage = (votes: number, totalVotes: number) => {
    return totalVotes === 0 ? 0 : Math.round((votes / totalVotes) * 100)
  }

  const nextPoll = () => {
    if (activePollIndex < polls.length - 1) {
      setActivePollIndex(activePollIndex + 1)
    } else {
      setActivePollIndex(0)
    }
  }

  const prevPoll = () => {
    if (activePollIndex > 0) {
      setActivePollIndex(activePollIndex - 1)
    } else {
      setActivePollIndex(polls.length - 1)
    }
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-yellow-500" />
          <p className="font-bold text-blue-900">Your Points: {userPoints}</p>
        </div>
        <Badge className="bg-yellow-500 text-blue-900">Fan Level: Super Fan</Badge>
      </div>

      <div className="relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={activePollIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-yellow-500 mb-4">
              <CardContent className="p-4">
                <div className="mb-4">
                  <h4 className="font-bold text-blue-900 mb-1">{polls[activePollIndex].question}</h4>
                  <p className="text-sm text-gray-500">{polls[activePollIndex].totalVotes} votes</p>
                </div>

                <div className="space-y-3">
                  {polls[activePollIndex].options.map((option) => (
                    <div key={option.id} className="space-y-1">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium text-blue-900">{option.text}</p>
                        <p className="text-sm text-gray-500">
                          {calculatePercentage(option.votes, polls[activePollIndex].totalVotes)}%
                        </p>
                      </div>
                      <div className="flex gap-2 items-center">
                        <Progress
                          value={calculatePercentage(option.votes, polls[activePollIndex].totalVotes)}
                          className="h-2"
                        />
                        {polls[activePollIndex].userVoted === null && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 text-xs border-yellow-500 text-yellow-600 hover:bg-yellow-50"
                            onClick={() => handleVote(polls[activePollIndex].id, option.id)}
                          >
                            Vote
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {polls[activePollIndex].userVoted !== null && (
                  <div className="mt-4 text-center">
                    <Badge className="bg-green-500">Thanks for voting! +10 points</Badge>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        <div className="flex justify-between">
          <Button
            variant="ghost"
            size="sm"
            className="text-blue-900 hover:text-blue-700 hover:bg-yellow-50 px-2"
            onClick={prevPoll}
          >
            Previous Poll
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-blue-900 hover:text-blue-700 hover:bg-yellow-50 px-2"
            onClick={nextPoll}
          >
            Next Poll
          </Button>
        </div>
      </div>
    </div>
  )
}

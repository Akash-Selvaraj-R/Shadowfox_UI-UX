"use client"

import { useState, useRef } from "react"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronLeft, ChevronRight, MapPin, Calendar, Clock } from "lucide-react"
import Image from "next/image"

export default function MatchSchedule() {
  const [activeIndex, setActiveIndex] = useState(0)
  const carouselRef = useRef<HTMLDivElement>(null)

  const matches = [
    {
      id: 1,
      team1: "CSK",
      team2: "MI",
      date: "April 20, 2025",
      time: "7:30 PM IST",
      venue: "M.A. Chidambaram Stadium, Chennai",
      ticketsAvailable: true,
    },
    {
      id: 2,
      team1: "CSK",
      team2: "RCB",
      date: "April 24, 2025",
      time: "7:30 PM IST",
      venue: "M.A. Chidambaram Stadium, Chennai",
      ticketsAvailable: true,
    },
    {
      id: 3,
      team1: "CSK",
      team2: "KKR",
      date: "April 28, 2025",
      time: "3:30 PM IST",
      venue: "Eden Gardens, Kolkata",
      ticketsAvailable: false,
    },
    {
      id: 4,
      team1: "CSK",
      team2: "SRH",
      date: "May 2, 2025",
      time: "7:30 PM IST",
      venue: "M.A. Chidambaram Stadium, Chennai",
      ticketsAvailable: true,
    },
    {
      id: 5,
      team1: "CSK",
      team2: "DC",
      date: "May 6, 2025",
      time: "7:30 PM IST",
      venue: "Arun Jaitley Stadium, Delhi",
      ticketsAvailable: false,
    },
  ]

  const nextSlide = () => {
    if (activeIndex < matches.length - 1) {
      setActiveIndex(activeIndex + 1)
      scrollToCard(activeIndex + 1)
    }
  }

  const prevSlide = () => {
    if (activeIndex > 0) {
      setActiveIndex(activeIndex - 1)
      scrollToCard(activeIndex - 1)
    }
  }

  const scrollToCard = (index: number) => {
    if (carouselRef.current) {
      const cardWidth = carouselRef.current.offsetWidth
      carouselRef.current.scrollTo({
        left: index * cardWidth,
        behavior: "smooth",
      })
    }
  }

  return (
    <div className="relative">
      <div ref={carouselRef} className="overflow-hidden">
        <motion.div className="flex" animate={{ x: `-${activeIndex * 100}%` }} transition={{ duration: 0.5 }}>
          {matches.map((match, index) => (
            <div key={match.id} className="min-w-full">
              <Card className="bg-blue-800 border-yellow-500 border-2 overflow-hidden">
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-3 gap-6 items-center">
                    <div className="flex flex-col items-center justify-center">
                      <div className="flex items-center justify-center gap-4 mb-4">
                        <div className="text-center">
                          <div className="bg-white rounded-full p-2 mb-2">
                            <Image src="https://4kwallpapers.com/images/walls/thumbs_3t/4938.png" alt={match.team1} width={60} height={60} />
                          </div>
                          <p className="font-bold text-white">{match.team1}</p>
                        </div>

                        <div className="text-yellow-500 font-bold text-xl">VS</div>

                        <div className="text-center">
                          <div className="bg-white rounded-full p-2 mb-2">
                            <Image src="https://pimwp.s3-accelerate.amazonaws.com/2021/06/large.png" alt={match.team2} width={60} height={60} />
                          </div>
                          <p className="font-bold text-white">{match.team2}</p>
                        </div>
                      </div>

                      <Badge className={match.ticketsAvailable ? "bg-green-500" : "bg-red-500"}>
                        {match.ticketsAvailable ? "Tickets Available" : "Sold Out"}
                      </Badge>
                    </div>

                    <div className="space-y-3 text-center md:text-left">
                      <div className="flex items-center gap-2 justify-center md:justify-start">
                        <Calendar className="h-4 w-4 text-yellow-500" />
                        <p className="text-white">{match.date}</p>
                      </div>
                      <div className="flex items-center gap-2 justify-center md:justify-start">
                        <Clock className="h-4 w-4 text-yellow-500" />
                        <p className="text-white">{match.time}</p>
                      </div>
                      <div className="flex items-center gap-2 justify-center md:justify-start">
                        <MapPin className="h-4 w-4 text-yellow-500" />
                        <p className="text-white">{match.venue}</p>
                      </div>
                    </div>

                    <div className="flex flex-col gap-3 items-center md:items-end">
                      <Button className="bg-yellow-500 hover:bg-yellow-600 text-blue-900 w-full md:w-auto">
                        {match.ticketsAvailable ? "Buy Tickets" : "Join Waitlist"}
                      </Button>
                      <Button
                        variant="outline"
                        className="border-yellow-500 text-yellow-500 hover:bg-blue-700 w-full md:w-auto"
                      >
                        Match Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </motion.div>
      </div>

      <div className="flex justify-center gap-4 mt-6">
        <Button
          variant="outline"
          size="icon"
          className="rounded-full border-yellow-500 text-yellow-500 hover:bg-blue-800 hover:text-yellow-400"
          onClick={prevSlide}
          disabled={activeIndex === 0}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>

        <div className="flex gap-2">
          {matches.map((_, index) => (
            <button
              key={index}
              className={`w-3 h-3 rounded-full ${activeIndex === index ? "bg-yellow-500" : "bg-blue-700"}`}
              onClick={() => {
                setActiveIndex(index)
                scrollToCard(index)
              }}
            />
          ))}
        </div>

        <Button
          variant="outline"
          size="icon"
          className="rounded-full border-yellow-500 text-yellow-500 hover:bg-blue-800 hover:text-yellow-400"
          onClick={nextSlide}
          disabled={activeIndex === matches.length - 1}
        >
          <ChevronRight className="h-6 w-6" />
        </Button>
      </div>
    </div>
  )
}

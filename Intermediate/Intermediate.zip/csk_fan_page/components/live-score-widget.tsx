"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { RefreshCw } from "lucide-react"

export default function LiveScoreWidget() {
  const [isLive, setIsLive] = useState(true)
  const [score, setScore] = useState({
    team1: "CSK",
    team2: "MI",
    team1Score: "186/4",
    team2Score: "120/3",
    overs: "15.2",
    batsman1: "Dhoni",
    batsman1Score: "45(28)",
    batsman2: "Jadeja",
    batsman2Score: "32(18)",
    bowler: "Bumrah",
    bowlerFigures: "3/24",
    recentBalls: ["1", "6", "W", "0", "4", "2"],
  })

  const [isRefreshing, setIsRefreshing] = useState(false)

  const refreshScore = () => {
    setIsRefreshing(true)
    setTimeout(() => {
      // In a real app, this would fetch updated scores from an API
      setScore({
        ...score,
        team2Score: "126/3",
        overs: "16.0",
        batsman1Score: "48(30)",
        batsman2Score: "35(20)",
        recentBalls: ["4", "1", "1", "0", "4", "2"],
      })
      setIsRefreshing(false)
    }, 1000)
  }

  return (
    <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5 }}>
      <Card className="overflow-hidden border-2 border-yellow-500">
        <div className="bg-gradient-to-r from-yellow-500 to-yellow-400 p-3 flex justify-between items-center">
          <div className="flex items-center gap-2">
            {isLive && (
              <motion.div
                className="w-3 h-3 rounded-full bg-red-500"
                animate={{ opacity: [1, 0.5, 1] }}
                transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
              />
            )}
            <h3 className="font-bold text-blue-900">{isLive ? "LIVE SCORE" : "MATCH RESULT"}</h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="text-blue-900 hover:bg-yellow-600"
            onClick={refreshScore}
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
        </div>

        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-3">
              <Image src="https://4kwallpapers.com/images/walls/thumbs_3t/4938.png" alt="CSK" width={40} height={40} />
              <div>
                <p className="font-bold text-lg">{score.team1}</p>
                <p className="text-xl font-bold text-blue-900">{score.team1Score}</p>
              </div>
            </div>

            <div className="text-center">
              <Badge className="bg-blue-900 mb-1">IPL 2025</Badge>
              <p className="text-sm text-gray-500">vs</p>
            </div>

            <div className="flex items-center gap-3">
              <div>
                <p className="font-bold text-lg">{score.team2}</p>
                <p className="text-xl font-bold text-blue-900">{score.team2Score}</p>
              </div>
              <Image src="https://4kwallpapers.com/images/walls/thumbs_3t/4934.png" alt="MI" width={40} height={40} />
            </div>
          </div>

          <div className="bg-yellow-50 p-3 rounded-lg mb-4">
            <div className="flex justify-between items-center mb-2">
              <p className="text-sm text-gray-500">
                Overs: <span className="font-bold text-blue-900">{score.overs}</span>
              </p>
              <p className="text-sm text-gray-500">
                Required: <span className="font-bold text-blue-900">67 runs (28 balls)</span>
              </p>
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-500">
                  {score.batsman1}: <span className="font-bold text-blue-900">{score.batsman1Score}</span>
                </p>
                <p className="text-sm text-gray-500">
                  {score.batsman2}: <span className="font-bold text-blue-900">{score.batsman2Score}</span>
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">
                  {score.bowler}: <span className="font-bold text-blue-900">{score.bowlerFigures}</span>
                </p>
              </div>
            </div>
          </div>

          <div>
            <p className="text-sm text-gray-500 mb-2">Recent Balls:</p>
            <div className="flex gap-2">
              {score.recentBalls.map((ball, index) => (
                <motion.div
                  key={index}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: index * 0.1, duration: 0.3 }}
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm
                    ${
                      ball === "W"
                        ? "bg-red-500 text-white"
                        : ball === "6"
                          ? "bg-green-500 text-white"
                          : ball === "4"
                            ? "bg-blue-500 text-white"
                            : "bg-gray-200 text-blue-900"
                    }`}
                >
                  {ball}
                </motion.div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}

"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle, Repeat } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function SocialFeed() {
  const tweets = [
    {
      id: 1,
      user: {
        name: "CSK Official",
        handle: "@ChennaiIPL",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: "Gearing up for another exciting season! The Super Kings are ready to roar! 🦁💛 #WhistlePodu #Yellove",
      time: "2h ago",
      likes: 2450,
      retweets: 876,
      comments: 234,
      isVerified: true,
    },
    {
      id: 2,
      user: {
        name: "MS Dhoni Fan Club",
        handle: "@MSDFansOfficial",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: "Can't wait to see Thala back in action! This season is going to be epic! 💛🏆 #ThalaForever #CSK",
      time: "5h ago",
      likes: 1890,
      retweets: 567,
      comments: 123,
      isVerified: false,
    },
    {
      id: 3,
      user: {
        name: "Cricket Analyst",
        handle: "@CricketExpert",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content:
        "CSK's batting lineup looks formidable this season. Their middle order depth could be the key to success in IPL 2025. #IPLAnalysis #CSK",
      time: "8h ago",
      likes: 780,
      retweets: 234,
      comments: 56,
      isVerified: true,
    },
    {
      id: 4,
      user: {
        name: "Yellow Army",
        handle: "@CSKYellowArmy",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content:
        "Chepauk is ready to welcome our Super Kings! The atmosphere is going to be electric! 💛🏟️ #WhistlePodu #HomeComing",
      time: "12h ago",
      likes: 1230,
      retweets: 456,
      comments: 89,
      isVerified: false,
    },
  ]

  return (
    <ScrollArea className="h-[400px] pr-4">
      <div className="space-y-4">
        {tweets.map((tweet, index) => (
          <motion.div
            key={tweet.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, duration: 0.3 }}
          >
            <Card className="border-gray-200">
              <CardContent className="p-4">
                <div className="flex gap-3">
                  <Avatar>
                    <AvatarImage src={tweet.user.avatar || "/placeholder.svg"} alt={tweet.user.name} />
                    <AvatarFallback>{tweet.user.name.charAt(0)}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1">
                    <div className="flex items-center gap-1">
                      <p className="font-bold text-blue-900">{tweet.user.name}</p>
                      {tweet.isVerified && (
                        <svg className="h-4 w-4 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                        </svg>
                      )}
                    </div>
                    <p className="text-sm text-gray-500 mb-2">{tweet.user.handle}</p>

                    <p className="text-blue-900 mb-3">{tweet.content}</p>

                    <div className="flex justify-between text-sm text-gray-500">
                      <p>{tweet.time}</p>
                      <div className="flex items-center gap-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-gray-500 hover:text-red-500 hover:bg-transparent"
                        >
                          <Heart className="h-4 w-4 mr-1" />
                          {tweet.likes}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-gray-500 hover:text-green-500 hover:bg-transparent"
                        >
                          <Repeat className="h-4 w-4 mr-1" />
                          {tweet.retweets}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-gray-500 hover:text-blue-500 hover:bg-transparent"
                        >
                          <MessageCircle className="h-4 w-4 mr-1" />
                          {tweet.comments}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </ScrollArea>
  )
}

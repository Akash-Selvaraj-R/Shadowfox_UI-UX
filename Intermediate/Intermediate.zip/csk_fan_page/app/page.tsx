"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronRight, Twitter, Instagram, Facebook, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import Image from "next/image"
import PlayerCard from "@/components/player-card"
import LiveScoreWidget from "@/components/live-score-widget"
import SocialFeed from "@/components/social-feed"
import FanPoll from "@/components/fan-poll"
import MatchSchedule from "@/components/match-schedule"

export default function Home() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const players = [
    {
      id: 1,
      name: "MS Dhoni",
      role: "Wicket-keeper",
      image: "https://images.indianexpress.com/2023/05/Dhoni-14.jpg",
      stats: { matches: 250, runs: 5000, average: 38.5 },
    },
    {
      id: 2,
      name: "Ravindra Jadeja",
      role: "All-rounder",
      image: "https://img-cdn.thepublive.com/fit-in/640x430/filters:format(webp)/newsdrum-in/media/media_files/xlutHLgQX974i7ojO1h1.jpg",
      stats: { matches: 200, wickets: 150, runs: 2000 },
    },
    {
      id: 3,
      name: "Ruturaj Gaikwad",
      role: "Batsman",
      image: "https://i.pinimg.com/736x/47/51/26/47512678e9bd8aadd76530d37ba2d499.jpg",
      stats: { matches: 50, runs: 1500, average: 42.3 },
    },
    {
      id: 4,
      name: "Sam Curran",
      role: "Bowler",
      image: "https://static.toiimg.com/thumb/msid-86783060,width-1280,height-720,resizemode-4/86783060.jpg",
      stats: { matches: 70, wickets: 80, economy: 7.8 },
    },
  ]

  const newsItems = [
    {
      id: 1,
      title: "CSK announces new jersey for IPL 2025",
      date: "April 10, 2025",
      image: "https://static.toiimg.com/thumb/msid-90396206,width-1070,height-580,imgsize-42106,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg",
    },
    {
      id: 2,
      title: "MS Dhoni confirms participation in next season",
      date: "April 8, 2025",
      image: "https://sc0.blr1.cdn.digitaloceanspaces.com/article/148841-clraytzonv-1602133322.jpg",
    },
    {
      id: 3,
      title: "Team begins training camp ahead of tournament",
      date: "April 5, 2025",
      image: "https://static.toiimg.com/thumb/msid-108776730,width-400,resizemode-4/108776730.jpg",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-white">
      {/* Navbar */}
      <motion.header
        className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? "bg-yellow-500 shadow-md py-2" : "bg-transparent py-4"}`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <motion.div className="flex items-center gap-2" whileHover={{ scale: 1.05 }}>
              <Image
                src="https://icon2.cleanpng.com/20180515/ow/avrm32nkn.webp"
                alt="CSK Logo"
                width={scrolled ? 40 : 50}
                height={scrolled ? 40 : 50}
                className="transition-all duration-300"
              />
              <span
                className={`font-bold text-xl md:text-2xl transition-all duration-300 ${scrolled ? "text-blue-900" : "text-yellow-500"}`}
              >
                CSK FANS
              </span>
            </motion.div>

            <div className="hidden md:flex items-center gap-6">
              {["Home", "Team", "Matches", "News", "Gallery", "Fan Zone"].map((item) => (
                <motion.a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className={`font-medium transition-all duration-300 ${scrolled ? "text-blue-900 hover:text-blue-700" : "text-yellow-600 hover:text-yellow-800"}`}
                  whileHover={{ scale: 1.1 }}
                >
                  {item}
                </motion.a>
              ))}
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">Join Fan Club</Button>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </Button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            className="fixed inset-0 bg-yellow-500 z-40 pt-20 px-4"
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex flex-col gap-4">
              {["Home", "Team", "Matches", "News", "Gallery", "Fan Zone"].map((item) => (
                <motion.a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-blue-900 font-medium text-xl py-3 border-b border-yellow-400"
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item}
                </motion.a>
              ))}
              <Button className="bg-blue-600 hover:bg-blue-700 text-white mt-4">Join Fan Club</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <motion.section
        className="relative h-screen flex items-center justify-center overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <div className="absolute inset-0 z-0">
          <Image
            src="ttps://media.crictracker.com/media/attachments/1674543242945_CSK-Logo.jpeg"
            alt="CSK Stadium"
            fill
            className="object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-yellow-500/30 to-blue-900/40" />
        </div>

        <div className="container mx-auto px-4 z-10">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <motion.div
              className="text-center md:text-left"
              initial={{ x: -100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.7 }}
            >
              <Badge className="mb-4 bg-yellow-500 text-blue-900 px-4 py-1 text-sm">IPL 2025</Badge>
              <h1 className="text-4xl md:text-6xl font-bold text-yellow-500 mb-4">CHENNAI SUPER KINGS</h1>
              <p className="text-xl md:text-2xl text-white mb-8">The most passionate fanbase in cricket</p>
              <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                <Button className="bg-yellow-500 hover:bg-yellow-600 text-blue-900 font-bold">Latest Updates</Button>
                <Button variant="outline" className="border-yellow-500 text-yellow-500 hover:bg-yellow-500/10">
                  Match Schedule
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.7 }}
              className="hidden md:block"
            >
              <Image
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCxeHCtxiKYUJcNxSkmJMSRNX9ipi7xbIh0A&s"
                alt="CSK Trophy"
                width={500}
                height={500}
                className="mx-auto"
              />
            </motion.div>
          </div>
        </div>

        <motion.div
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
        >
          <motion.div
            className="flex items-center gap-2 text-white cursor-pointer"
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
            onClick={() => window.scrollTo({ top: window.innerHeight, behavior: "smooth" })}
          >
            <span>Scroll Down</span>
            <ChevronRight className="rotate-90" />
          </motion.div>
        </motion.div>
      </motion.section>

      {/* Live Score Widget */}
      <section className="py-8 bg-blue-900">
        <div className="container mx-auto px-4">
          <LiveScoreWidget />
        </div>
      </section>

      {/* Team News */}
      <motion.section
        className="py-16 bg-white"
        id="news"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge className="mb-2 bg-yellow-500 text-blue-900">LATEST</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Team News</h2>
            <div className="w-20 h-1 bg-yellow-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {newsItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                <Card className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
                  <div className="relative h-48">
                    <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
                  </div>
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-500 mb-2">{item.date}</p>
                    <h3 className="text-xl font-bold text-blue-900 mb-3">{item.title}</h3>
                    <Button variant="link" className="text-yellow-600 p-0">
                      Read More <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-10">
            <Button className="bg-blue-900 hover:bg-blue-800">View All News</Button>
          </div>
        </div>
      </motion.section>

      {/* Player Cards */}
      <motion.section
        className="py-16 bg-gradient-to-b from-yellow-50 to-white"
        id="team"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge className="mb-2 bg-yellow-500 text-blue-900">SQUAD</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Meet Our Champions</h2>
            <div className="w-20 h-1 bg-yellow-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {players.map((player, index) => (
              <motion.div
                key={player.id}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                <PlayerCard player={player} />
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-10">
            <Button className="bg-blue-900 hover:bg-blue-800">View Full Squad</Button>
          </div>
        </div>
      </motion.section>

      {/* Match Schedule */}
      <motion.section
        className="py-16 bg-blue-900 text-white"
        id="matches"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge className="mb-2 bg-yellow-500 text-blue-900">FIXTURES</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Upcoming Matches</h2>
            <div className="w-20 h-1 bg-yellow-500 mx-auto"></div>
          </div>

          <MatchSchedule />
        </div>
      </motion.section>

      {/* Fan Zone */}
      <motion.section
        className="py-16 bg-white"
        id="fan-zone"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge className="mb-2 bg-yellow-500 text-blue-900">INTERACT</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Fan Zone</h2>
            <div className="w-20 h-1 bg-yellow-500 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <div className="bg-yellow-50 rounded-lg p-6 h-full">
                <h3 className="text-2xl font-bold text-blue-900 mb-6">Fan Polls</h3>
                <FanPoll />
              </div>
            </motion.div>

            <motion.div
              initial={{ x: 50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <div className="bg-yellow-50 rounded-lg p-6 h-full">
                <h3 className="text-2xl font-bold text-blue-900 mb-6">Social Feed</h3>
                <SocialFeed />
              </div>
            </motion.div>
          </div>

          <motion.div
            className="mt-12 bg-gradient-to-r from-yellow-500 to-yellow-400 rounded-lg p-8 text-center"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <h3 className="text-2xl md:text-3xl font-bold text-blue-900 mb-4">Join The CSK Fan Club</h3>
            <p className="text-blue-900 mb-6 max-w-2xl mx-auto">
              Get exclusive content, match tickets priority, and special merchandise discounts by joining our official
              fan club.
            </p>
            <Button className="bg-blue-900 hover:bg-blue-800 text-white">Become a Member</Button>
          </motion.div>
        </div>
      </motion.section>

      {/* Footer */}
      <footer className="bg-blue-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Image src="https://icon2.cleanpng.com/20180515/ow/avrm32nkn.webp" alt="CSK Logo" width={50} height={50} />
                <span className="font-bold text-xl text-yellow-500">CSK FANS</span>
              </div>
              <p className="text-gray-300 mb-4">
                The official fan website for Chennai Super Kings supporters around the world.
              </p>
              <div className="flex gap-4">
                <Button variant="ghost" size="icon" className="text-yellow-500 hover:text-yellow-400 hover:bg-blue-800">
                  <Twitter />
                </Button>
                <Button variant="ghost" size="icon" className="text-yellow-500 hover:text-yellow-400 hover:bg-blue-800">
                  <Instagram />
                </Button>
                <Button variant="ghost" size="icon" className="text-yellow-500 hover:text-yellow-400 hover:bg-blue-800">
                  <Facebook />
                </Button>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-yellow-500 mb-4">Quick Links</h4>
              <ul className="space-y-2">
                {["Home", "Team", "Matches", "News", "Gallery", "Fan Zone"].map((item) => (
                  <li key={item}>
                    <Link href={`#${item.toLowerCase()}`} className="text-gray-300 hover:text-yellow-500">
                      {item}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-yellow-500 mb-4">Information</h4>
              <ul className="space-y-2">
                {["About Us", "Contact", "Privacy Policy", "Terms of Service", "FAQ"].map((item) => (
                  <li key={item}>
                    <Link href="#" className="text-gray-300 hover:text-yellow-500">
                      {item}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-yellow-500 mb-4">Newsletter</h4>
              <p className="text-gray-300 mb-4">Subscribe to get the latest news and updates.</p>
              <div className="flex gap-2">
                <input
                  type="email"
                  placeholder="Your email"
                  className="px-4 py-2 rounded-md bg-blue-800 text-white border border-blue-700 focus:outline-none focus:ring-2 focus:ring-yellow-500 flex-grow"
                />
                <Button className="bg-yellow-500 hover:bg-yellow-600 text-blue-900">Subscribe</Button>
              </div>
            </div>
          </div>

          <div className="border-t border-blue-800 mt-8 pt-8 text-center text-gray-400">
            <p>© {new Date().getFullYear()} Chennai Super Kings Fan Club. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
